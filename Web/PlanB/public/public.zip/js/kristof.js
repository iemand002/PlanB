$("#locatie").geocomplete({
  details: "form",
  detailsAttribute: "data-geo"
});