<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gevolgd_project extends Model {

	protected $table = 'gevolgde_projecten';
	public $timestamps = true;

}